<footer class="footer">
    <a><img src="{{ asset($setting->logo) }}" alt="logo" width="100" height="50"></a>
    <p>Copyright ©{{ date('Y') }} eBoighar.com. All Rights Reserved.</p>
</footer>
