<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Return Orders</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a
                    href="<?php echo e(route('return.index')); ?>">Return Order List</a></div>
        </div>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Invoice No</th>
                                <th scope="col">User</th>
                                <th scope="col">Total Amount</th>
                                <th scope="col">Reason</th>
                                <th scope="col">Status</th>
                                <th scope="col">Is Reject</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $return_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td>
                                        <a href="<?php echo e(route('order.show',$item->order->id)); ?>"><?php echo e($item->order->invoice_no); ?></a>
                                    </td>
                                    <td><?php echo e($item->user->name); ?></td>
                                    <td><?php echo e(round(@$item->order->total_payable,2)); ?> ৳</td>
                                    <td><?php echo e($item->reason); ?></td>
                                    <td>
                                        <?php if($item->status == 0): ?>
                                            <div class="badge badge-warning">Pending</div>
                                        <?php else: ?>
                                            <div class="badge badge-success">Approved</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->is_reject == 0): ?>
                                            <div class="badge badge-warning">No</div>
                                        <?php else: ?>
                                            <div class="badge badge-success">Yes</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->is_reject == 0 && $item->status == 0): ?>
                                            <a class="btn btn-success"
                                               href="<?php echo e(route('status.update',['table' => 'return_orders', 'id' => $item->id])); ?>"><i
                                                    class="fas fa-check"></i></a>
                                            <a class="btn btn-info"
                                               href="<?php echo e(route('reject.return',$item->id)); ?>"><i
                                                    class="fas fa-times"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-right">
                        <?php echo e($return_orders->links('vendor.pagination.bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/backend/return_order/index.blade.php ENDPATH**/ ?>