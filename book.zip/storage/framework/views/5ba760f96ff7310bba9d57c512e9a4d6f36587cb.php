<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(url('/')); ?>">Stisla</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(url('/')); ?>">St</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-fire"></i> <span>Dashboard</span></a></li>
            <li class="menu-header">Category</li>
            <li class="<?php echo e(request()->is('categories') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('category.index')); ?>"><i class="fa fa-bars"></i> <span>Category</span></a></li>
            <li class="menu-header">Author</li>
            <li class="<?php echo e(request()->is('authors') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('author.index')); ?>"><i class="fa fa-user"></i> <span>Author</span></a></li>
            <li class="menu-header">Customer</li>
            <li class="<?php echo e(request()->is('customers') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('customer.index')); ?>"><i class="fa fa-user"></i> <span>Customers</span></a></li>
            <li class="menu-header">Book</li>
            <li class="<?php echo e(request()->is('books') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('book.index')); ?>"><i class="fa fa-book"></i> <span>Book</span></a></li>
            <li class="menu-header">Order</li>
            <li class="<?php echo e(request()->is('order-list') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('order.index')); ?>"><i class="fa fa-book"></i> <span>Order</span></a></li>
            <li class="menu-header">Return Order</li>
            <li class="<?php echo e(request()->is('return-order-list') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('return.index')); ?>"><i class="fa fa-backward"></i> <span>Return Order</span></a></li>
            
            <li class="menu-header">Settings</li>
            <li class="<?php echo e(request()->is('settings') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('settings')); ?>"><i class="fa fa-cog"></i> <span>Settings</span></a></li>

        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-lg btn-block btn-icon-split">
                <i class="fas fa-rocket"></i> Visit Website
            </a>
        </div>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\book\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>