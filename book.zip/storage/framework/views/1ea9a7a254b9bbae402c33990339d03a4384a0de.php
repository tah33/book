<div class="container-fluid topbar_sec">
    <div class="container">
        
        <div class="row">
            <div class="col-lg-2 d-flex justify-content-between">
                <div class="dropdown">
                    <button class="btn btn-secondary bar_color" type="button" id="dropdown_btn" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bars"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdown_btn">
                        <?php $__currentLoopData = $sidebar_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('category.books',$category->id)); ?>"><?php echo e($category->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset($setting->logo)); ?>" alt="logo" width="100" height="50"></a>
            </div>
            <div class="col-lg-8 d-flex justify-content-center">
                <form action="<?php echo e(route('search.book')); ?>" method="POST"><?php echo csrf_field(); ?>
                    <div class="input-group search_btn">
                        <input type="text" class="form-control" name="value"
                               placeholder="Enter Book Name/Author Name to Search Books">
                        <div class="input-group-append">
                            <button type="submit" class="input-group-text"><i
                                    class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-2 d-flex justify-content-end">
                <?php if(auth()->check()): ?>
                    <a href="<?php echo e(url('login')); ?>" class="login_btn mr-3">Dashboard</a>
                    <a href="<?php echo e(route('logout')); ?>" class="login_btn mr-3" onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(url('dashboard')); ?>" class="login_btn mr-3">Login</a>
                <?php endif; ?>
                <a href="<?php echo e(route('cart.lists')); ?>" class="bar_color d-inline-block mt-1"><i
                        class="fa fa-shopping-cart"></i><span class="cart_number"><?php echo e(count($carts)); ?></span></a>
            </div>
        </div>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/header.blade.php ENDPATH**/ ?>