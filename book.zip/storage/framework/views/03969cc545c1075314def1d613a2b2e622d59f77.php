<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Online Book Selling</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/font_awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/rateit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/toastr.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset($setting->favicon)); ?>"/>
</head>
<body>
<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('section'); ?>
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/backend/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/tooltip.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.rateit.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
<script src="<?php echo e(asset('assets/backend/js/toastr.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>
<?php echo Toastr::message(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/master.blade.php ENDPATH**/ ?>