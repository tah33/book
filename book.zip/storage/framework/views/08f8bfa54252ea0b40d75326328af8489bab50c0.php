<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Customers</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a
                    href="<?php echo e(route('customer.index')); ?>">Customer List</a></div>
        </div>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Image</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Username</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?></a></td>
                                    <td><?php echo e($item->username); ?></td>
                                    <td><a href="tel:<?php echo e($item->phone); ?>"><?php echo e($item->phone); ?></a></td>
                                    <td>
                                        <?php if($item->status == 0): ?>
                                            <div class="badge badge-danger">Inactive</div>
                                        <?php else: ?>
                                            <div class="badge badge-success">Active</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown d-inline">
                                            <button class="btn btn-primary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton2"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Action
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start">
                                                <?php if($item->status == 0): ?>
                                                    <a class="dropdown-item has-icon"
                                                       href="<?php echo e(route('status.update',['table' => 'users','id' => $item->id])); ?>"><i
                                                            class="fas fa-check"></i> Active</a>
                                                <?php else: ?>
                                                    <a class="dropdown-item has-icon"
                                                       href="<?php echo e(route('status.inactive',['table' => 'users','id' => $item->id])); ?>"><i
                                                            class="fas fa-times"></i> Inactive</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-right">
                        <?php echo e($customers->links('vendor.pagination.bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/backend/customer/index.blade.php ENDPATH**/ ?>