<div class="card">
    <div class="card-header">
        <h4>Book</h4>
        <div class="card-header-form">
            <a href="<?php echo e(route('book.create')); ?>" class="btn btn-primary float-right"><i
                    class="fa fa-plus"></i> Add New Book </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Image</th>
                <th scope="col">Title</th>
                <th scope="col">Category</th>
                <th scope="col">Author</th>
                <th scope="col">Price</th>
                <th scope="col">Stock</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key+1); ?></th>
                    <td><img src="<?php echo e(asset($item->image)); ?>" width="60" alt="<?php echo e($item->title); ?>"></td>
                    <td><?php echo e($item->title); ?></td>
                    <td><?php echo e(@$item->category->title); ?></td>
                    <td><?php echo e(@$item->author->name); ?></td>
                    <td><?php echo e(round(@$item->price,2)); ?> ৳</td>
                    <td><?php echo e($item->stock); ?></td>
                    <td>
                        <?php if($item->status == 1): ?>
                            <div class="badge badge-success">Published</div>
                        <?php else: ?>
                            <div class="badge badge-danger">Unpublished</div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="dropdown d-inline">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Action
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start">
                                <?php if($item->status == 0): ?>
                                    <a class="dropdown-item has-icon"
                                       href="<?php echo e(route('status.update',['table' => 'books','id' => $item->id])); ?>"><i
                                            class="fas fa-check"></i> Publish</a>
                                <?php else: ?>
                                    <a class="dropdown-item has-icon"
                                       href="<?php echo e(route('status.inactive',['table' => 'books','id' => $item->id])); ?>"><i
                                            class="fas fa-times"></i> Unpublish</a>
                                <?php endif; ?>

                                <a class="dropdown-item has-icon"
                                   href="#" data-toggle="modal" data-target="#stock_modify_<?php echo e($item->id); ?>"><i
                                        class="fas fa-book"></i> Modify Stock</a>
                                <a class="dropdown-item has-icon"
                                   href="<?php echo e(route('book.edit',$item->id)); ?>"><i
                                        class="fas fa-pencil-alt"></i> Edit</a>

                                <a class="dropdown-item has-icon trash_btn" href="#"><i
                                        class="fas fa-trash"></i> Delete</a>
                            </div>
                        </div>
                        <div class="modal fade" id="stock_modify_<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                             aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLongTitle">Modify Stock</h5>
                                        <button type="button" class="close" aria-label="Close"
                                                onclick="closeModal('stock_modify_<?php echo e($item->id); ?>')">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('stock.modify')); ?>" method="POST"><?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                            <div class="form-group col-lg-4">
                                                <label class="d-block">Type</label>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" id="inlineradio1"
                                                           value="add" name="type">
                                                    <label class="form-check-label mr-3"
                                                           for="inlineradio1">Increase</label>
                                                    <input class="form-check-input" type="radio" id="inlineradio2"
                                                           value="minus" name="type">
                                                    <label class="form-check-label" for="inlineradio2">Decrease</label>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-12">
                                                <label for="quantity">Quantity <strong
                                                        class="text-danger">*</strong></label>
                                                <input type="number" class="form-control" id="quantity" name="quantity"
                                                       placeholder="Stock" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                    onclick="closeModal('stock_modify_<?php echo e($item->id); ?>')">Close
                                            </button>
                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <form class="trash_form" action="<?php echo e(route('book.destroy',$item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer text-right">
        <?php echo e($books->links('vendor.pagination.bootstrap-4')); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\book\resources\views/backend/book/table.blade.php ENDPATH**/ ?>