<?php $__env->startSection('section'); ?>
    <div class="container-fluid book_section">
        <div class="container">
            <div class="d-flex justify-content-between border-bottom mb-3">
                <h1 class="border-0">Latest Books</h1>
                <a class="all_books" href="<?php echo e(route('all.books')); ?>">All Books <i class="fa fa-arrow-right"></i></a>
            </div>
            <div class="row">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 mb-3">
                        <div class="card">
                            <a href="<?php echo e(route('books.details',$book->id)); ?>">
                                <img class="card-img-top" height="250"
                                     src="<?php echo e(asset($book->image)); ?>"
                                     alt="Card image cap">
                            </a>
                            <div class="card-body text-left">
                                <h5 class="card-title"><a href="<?php echo e(route('books.details',$book->id)); ?>"><?php echo e($book->title); ?></a></h5>
                                <p class="card-text"><span class="symbol">৳</span> <?php echo e(round($book->price,2)); ?> </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div class="container-fluid book_section">
        <div class="container">
            <h1 class="mt-2 mb-4">Latest Categories</h1>
            <div class="card-deck">
                <div class="row text-center">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-2 mb-3">
                            <a href="<?php echo e(route('category.books',$category->id)); ?>"><img
                                    src="<?php echo e(asset($category->image)); ?>" alt="<?php echo e($category->title); ?>" width="200"
                                    height="150"></a>
                            <a class="image_title"
                               href="<?php echo e(route('category.books',$category->id)); ?>"><?php echo e($category->title); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container-fluid book_section">
        <div class="container">
            <h1 class="mt-2 mb-4">Popular Authors</h1>
            <div class="card-deck">
                <div class="row text-center">
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-2 mb-3">
                            <a href="<?php echo e(route('author.books',$author->id)); ?>"><img src="<?php echo e(asset($author->image)); ?>"
                                                                                   alt="<?php echo e($author->name); ?>" width="200"
                                                                                   height="150"></a>
                            <a class="image_title"
                               href="<?php echo e(route('author.books',$author->id)); ?>"><?php echo e($author->name); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container-fluid book_section">
        <div class="container">
            <h1 class="mt-2 mb-4">About Us</h1>
            <div class="row">
                <div class="col-lg-12 text-left">
                    <p class="about_us">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias aliquid autem dicta itaque
                        molestiae nemo neque porro reiciendis sint! Adipisci architecto at blanditiis consequatur,
                        corporis dicta dolores ducimus ea earum facere labore magni maxime, neque odit quis sapiente,
                        tempore! Alias at distinctio error explicabo hic, itaque molestias odit officia quam quas? Est
                        facere odit omnis reiciendis repellat tempora! Ad architecto, commodi corporis dolores eos
                        fugiat impedit labore officiis sint vel! Consequuntur, cumque eveniet exercitationem fugiat in,
                        iure laborum modi necessitatibus, possimus quia rerum sint veritatis? Commodi ducimus ipsam
                        molestiae nihil nulla quia quis voluptatum. Animi deserunt dolorum eveniet reprehenderit
                        temporibus.
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/home.blade.php ENDPATH**/ ?>