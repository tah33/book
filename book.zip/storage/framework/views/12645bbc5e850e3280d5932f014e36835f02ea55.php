<footer class="footer">
    <a><img src="<?php echo e(asset($setting->logo)); ?>" alt="logo" width="100" height="50"></a>
    <p>Copyright ©<?php echo e(date('Y')); ?> eBoighar.com. All Rights Reserved.</p>
</footer>
<?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/footer.blade.php ENDPATH**/ ?>