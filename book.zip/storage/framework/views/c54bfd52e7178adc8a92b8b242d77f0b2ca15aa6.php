<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Orders</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a
                    href="<?php echo e(route('order.index')); ?>">Order List</a></div>
        </div>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Invoice No</th>
                                <th scope="col">User</th>
                                <th scope="col">Payment Type</th>
                                <th scope="col">Payment Status</th>
                                <th scope="col">Total Payable</th>
                                <th scope="col">Delivery Status</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><a href="<?php echo e(route('order.show',$item->id)); ?>"><?php echo e($item->invoice_no); ?></a></td>
                                    <td><?php echo e($item->user->email); ?></td>
                                    <td><?php echo e($item->payment_type); ?></td>
                                    <td>
                                    <?php if($item->payment_status == 0): ?>
                                            <div class="badge badge-warning">Unpaid</div>
                                
                                        <?php else: ?>
                                            <div class="badge badge-success">Paid</div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(round(@$item->total_payable,2)); ?> ৳</td>
                                    <td>
                                        <?php if($item->delivery_status == 0): ?>
                                            <div class="badge badge-warning">Pending</div>
                                        <?php elseif($item->delivery_status == 1): ?>
                                            <div class="badge badge-primary">Confirmed</div>
                                        <?php else: ?>
                                            <div class="badge badge-success">Delivered</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown d-inline">
                                            <button class="btn btn-primary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton2"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Action
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-start">
                                                <?php if($item->delivery_status == 0): ?>
                                                    <a class="dropdown-item has-icon"
                                                       href="<?php echo e(route('status.change',$item->id)); ?>"><i
                                                            class="fas fa-check"></i> Confirm</a>
                                                <?php else: ?>
                                                    <a class="dropdown-item has-icon"
                                                       href="<?php echo e(route('status.change',$item->id)); ?>"><i
                                                            class="fas fa-check"></i> Delivered</a>
                                                <?php endif; ?>
                                                <a class="dropdown-item has-icon"
                                                   href="<?php echo e(route('order.show',$item->id)); ?>"><i
                                                        class="fas fa-eye"></i> View</a>
                                            </div>
                                        </div>
                                        <form class="trash_form" action="<?php echo e(route('category.destroy',$item->id)); ?>"
                                              method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-right">
                        <?php echo e($orders->links('vendor.pagination.bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/backend/order/index.blade.php ENDPATH**/ ?>