<?php $__env->startSection('content'); ?>
    <div class="section-header">
        <h1>Books</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a
                    href="<?php echo e(route('book.index')); ?>">Category</a></div>
        </div>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <?php
                        $route = isset($book) ? route('book.update',$book->id) : route('book.store');
                    ?>

                    <form method="POST" action="<?php echo e($route); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">
                            <h4><?php echo e(isset($book) ? 'Edit' : 'Add'); ?> Book</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-lg-12">
                                    <label for="title">Title <strong class="text-danger">*</strong></label>
                                    <input type="text" class="form-control" id="title" name="title" placeholder="Title"
                                           value="<?php echo e(isset($book) ? $book->title : old('title')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('title')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="category_id">Category </label>
                                    <select name="category_id" class="form-control" id="category_id">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($category->id); ?>" <?php echo e(isset($book) && $book->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"> <?php echo e($errors->first('category_id')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="author_id">Author </label>
                                    <select name="author_id" class="form-control" id="author_id">
                                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($author->id); ?>" <?php echo e(isset($book) && $book->author_id == $author->id ? 'selected' : ''); ?>><?php echo e($author->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"> <?php echo e($errors->first('author_id')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="price">Price <strong class="text-danger">*</strong></label>
                                    <input type="number" step="any" class="form-control" id="price" name="price"
                                           placeholder="Price"
                                           value="<?php echo e(isset($book) ? $book->price : old('price')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('price')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="stock">Stock <strong class="text-danger">*</strong></label>
                                    <input type="number" class="form-control" id="stock" name="stock"
                                           placeholder="Stock"
                                           value="<?php echo e(isset($book) ? $book->stock : old('stock')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('stock')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="publisher">Publisher <strong class="text-danger">*</strong></label>
                                    <input type="text" class="form-control" id="publisher" name="publisher"
                                           placeholder="Publisher"
                                           value="<?php echo e(isset($book) ? $book->publisher : old('publisher')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('publisher')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="country">Country <strong class="text-danger">*</strong></label>
                                    <input type="text" class="form-control" id="country" name="country"
                                           placeholder="Country"
                                           value="<?php echo e(isset($book) ? $book->country : old('country')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('country')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="language">Language <strong class="text-danger">*</strong></label>
                                    <input type="text" class="form-control" id="language" name="language"
                                           placeholder="Language"
                                           value="<?php echo e(isset($book) ? $book->language : old('language')); ?>">
                                    <span class="text-danger"> <?php echo e($errors->first('language')); ?> </span>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="image">Image</label>
                                    <input type="file" class="form-control" id="image" name="image">
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="pdf">PDF file</label>
                                    <input type="file" class="form-control" id="pdf" name="pdf">
                                </div>
                                <div class="form-group col-lg-4">
                                    <label for="status">Status </label>
                                    <select name="status" class="form-control" id="status">
                                        <option value="1" <?php echo e(isset($book) && $book->status == 1 ? 'selected' : ''); ?>>
                                            Publish
                                        </option>
                                        <option value="0" <?php echo e(isset($book) && $book->status == 0 ? 'selected' : ''); ?>>
                                            Unpublish
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/backend/book/form.blade.php ENDPATH**/ ?>