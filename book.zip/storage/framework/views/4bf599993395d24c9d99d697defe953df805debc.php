<?php $__env->startSection('section'); ?>
    <div class="container-fluid book_section">
        <div class="container">
            <div class="d-flex justify-content-between border-bottom mb-3">
                <h1 class="border-0"><?php echo e(count($books)); ?> Books Found</h1>
            </div>
            <div class="row">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 mb-3">
                        <div class="card">
                            <a href="<?php echo e(route('books.details',$book->id)); ?>">
                                <img class="card-img-top" height="250"
                                     src="<?php echo e(asset($book->image)); ?>"
                                     alt="Card image cap">
                            </a>
                            <div class="card-body text-left">
                                <h5 class="card-title"><a href="<?php echo e(route('books.details',$book->id)); ?>"><?php echo e($book->title); ?></a></h5>
                                <p class="card-text"><span class="symbol">৳</span> <?php echo e(round($book->price,2)); ?> </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/all_books.blade.php ENDPATH**/ ?>